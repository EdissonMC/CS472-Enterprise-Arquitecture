package client;

public class Book {
    private String isbn;
    private String author;

    public Book(){}

    public Book(String isbn, String author) {
        this.isbn = isbn;
        this.author = author;
    }

    public String getIsbn() {
        return isbn;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }
}
