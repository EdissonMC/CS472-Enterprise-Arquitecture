package client;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.client.RestTemplate;

@SpringBootApplication
public class Application implements CommandLineRunner {

    RestTemplate restTemplate = new RestTemplate();
    private String serverUrl = "http://localhost:8080/books";

    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }

    @Override
    public void run(String... args) throws Exception {
        // Get all books
        System.out.println(restTemplate.getForObject(serverUrl, Object.class));

        // Get a book by isbn
        Book book = restTemplate.getForObject(serverUrl + "/2222222", Book.class);
        System.out.println(book);

        try {
            // Get a book by isbn which does not exist
            Book nonExistingBook = restTemplate.getForObject(serverUrl + "/2222222222", Book.class);
            System.out.println(nonExistingBook);
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }

        // Get books by author
        System.out.println(restTemplate.getForObject(serverUrl + "/author/Author 1", Object.class));

        // Update book
        book.setAuthor("New Author");
        restTemplate.put(serverUrl + "/" + book.getIsbn(), book);

        try {
        // Delete a book by isbn
        restTemplate.delete(serverUrl + "/1111111");
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }

        // Get all books
        System.out.println(restTemplate.getForObject(serverUrl, Object.class));

        // Create a book
        book = new Book("1111112", "Author 1");
        restTemplate.postForLocation(serverUrl, book);

        // Get all books
        System.out.println(restTemplate.getForObject(serverUrl, Object.class));
    }
}
