package mvc.service;

import mvc.entity.Book;
import mvc.exception.BookException;
import mvc.entity.Books;

public interface IBookService {
    Book getBook(String isbn) throws BookException;
    Book addBook(Book book);
    void deleteBook(String isbn) throws BookException;
    Book updateBook(String isbn, Book book) throws BookException;
    Books getAllBooks();
    Books searchBooks(String author);
}
