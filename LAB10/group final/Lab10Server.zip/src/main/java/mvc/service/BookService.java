package mvc.service;

import mvc.entity.Book;
import mvc.exception.BookException;
import mvc.entity.Books;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class BookService implements IBookService {
    private final Map<String, Book> books = new HashMap<>();

    public BookService() {
        List<Book> bookList = List.of(
                new Book("1111111", "Author 1"),
                new Book("2222222", "Author 2"),
                new Book("3333333", "Author 1"),
                new Book("4444444", "Author 1"),
                new Book("5555555", "Author 2")
        );

        for (Book book : bookList) {
            books.put(book.getIsbn(), book);
        }
    }

    public Book getBook(String isbn) throws BookException {
        Book book = books.get(isbn);
        if (book == null) {
            throw new BookException("Book with isbn= " + isbn + " is not available");
        }
        return book;
    }

    public Book addBook(Book book) {
        books.put(book.getIsbn(), book);
        return book;
    }

    public void deleteBook(String isbn) throws BookException {
        Book book = books.get(isbn);
        if (book == null) {
            throw new BookException("Book with isbn= " + isbn + " is not available");
        }
        books.remove(isbn);
    }

    public Book updateBook(String isbn, Book book) throws BookException {
        if (books.get(isbn) == null) {
            throw new BookException("Book with isbn= " + isbn + " is not available");
        }
        books.put(isbn, book);
        return book;
    }

    public Books getAllBooks() {
        return new Books(books.values());
    }

    public Books searchBooks(String author) {
        List<Book> filteredBooks = books.values().stream()
                .filter(b -> b.getAuthor().equals(author))
                .collect(Collectors.toList());
        return new Books(filteredBooks);
    }
}
