package mvc.controller;

import mvc.entity.Book;
import mvc.exception.BookException;
import mvc.service.IBookService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin
@RequestMapping("/books")
public class BookController {
    private final IBookService bookService;

    public BookController(IBookService bookService) {
        this.bookService = bookService;
    }

    @GetMapping("{isbn}")
    public ResponseEntity<?> getBook(@PathVariable String isbn) throws BookException {
        return new ResponseEntity<>(bookService.getBook(isbn), HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<?> addBook(@RequestBody Book book) {
        return new ResponseEntity<>(bookService.addBook(book), HttpStatus.OK);
    }

    @DeleteMapping("{isbn}")
    public ResponseEntity<?> deleteBook(@PathVariable String isbn) throws BookException {
        bookService.deleteBook(isbn);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @PutMapping("{isbn}")
    public ResponseEntity<?> updateBook(@PathVariable String isbn, @RequestBody Book book) throws BookException {
        return new ResponseEntity<>(bookService.updateBook(isbn, book), HttpStatus.OK);
    }

    @GetMapping
    public ResponseEntity<?> getAllBooks() {
        return new ResponseEntity<>(bookService.getAllBooks(), HttpStatus.OK);
    }

    @GetMapping("/author/{author}")
    public ResponseEntity<?> searchBooks(@PathVariable String author) {
        return new ResponseEntity<>(bookService.searchBooks(author), HttpStatus.OK);
    }
}

